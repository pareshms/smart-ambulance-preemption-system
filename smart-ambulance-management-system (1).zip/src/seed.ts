import { db, handleFirestoreError, OperationType } from './firebase';
import { collection, setDoc, doc } from 'firebase/firestore';

export async function seedData(userId?: string) {
  const hospitals = [
    { id: 'hosp_1', name: 'Manipal Hospital (HAL Road)', location: { lat: 12.9592, lng: 77.6444 }, availableBeds: 15 },
    { id: 'hosp_2', name: 'Apollo Hospitals (Bannerghatta)', location: { lat: 12.8959, lng: 77.5983 }, availableBeds: 8 },
    { id: 'hosp_3', name: 'Fortis Hospital (Cunningham Rd)', location: { lat: 12.9882, lng: 77.5948 }, availableBeds: 22 }
  ];

  const signals = [
    { id: 'signal_1', name: 'Silk Board Junction', location: { lat: 12.9176, lng: 77.6233 }, state: 'AUTO', isEmergencyOverride: false },
    { id: 'signal_2', name: 'Sony World Signal', location: { lat: 12.9344, lng: 77.6267 }, state: 'AUTO', isEmergencyOverride: false },
    { id: 'signal_3', name: 'Richmond Circle', location: { lat: 12.9667, lng: 77.5933 }, state: 'AUTO', isEmergencyOverride: false }
  ];

  try {
    for (const h of hospitals) {
      await setDoc(doc(db, 'hospitals', h.id), h);
    }

    for (const s of signals) {
      await setDoc(doc(db, 'signals', s.id), s);
    }

    if (userId) {
      const ambulances = [
        { id: `amb_${userId.slice(0, 5)}`, plateNumber: 'KA-01-AM-7842', driverId: userId, status: 'available', currentLocation: { lat: 12.9716, lng: 77.5946 } }
      ];

      for (const a of ambulances) {
        await setDoc(doc(db, 'ambulances', a.id), a);
      }
    }

    console.log("Seed data created successfully");
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'seeding');
  }
}
