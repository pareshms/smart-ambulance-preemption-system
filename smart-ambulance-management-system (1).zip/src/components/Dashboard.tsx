import React, { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, query, orderBy, limit, doc, updateDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'framer-motion';
import { io } from 'socket.io-client';
import { 
  MapContainer, 
  TileLayer, 
  Marker, 
  Popup,
  useMap,
  Polyline
} from 'react-leaflet';
import L from 'leaflet';
import { renderToStaticMarkup } from 'react-dom/server';
import { 
  Activity, 
  Map as MapIcon, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Navigation2,
  Signal,
  Zap,
  Ambulance,
  Phone,
  Settings
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '../lib/utils';

const socket = io();

const MapIconComponent = ({ icon: Icon, color, isEmergency }: { icon: any, color: string, isEmergency?: boolean }) => (
  <div className="relative">
    {isEmergency && (
      <div className="absolute -inset-2 bg-red-500/20 rounded-full animate-ping -z-10"></div>
    )}
    <div className={cn(
      "w-10 h-10 rounded-xl flex items-center justify-center shadow-lg border-2 border-white transition-all",
      color === 'emerald' ? "bg-emerald-600 shadow-emerald-600/40" :
      color === 'blue' ? "bg-blue-600 shadow-blue-600/40" :
      "bg-slate-600 shadow-slate-600/40 opacity-50"
    )}>
      <Icon className="w-6 h-6 text-white" />
    </div>
  </div>
);

const SignalIconComponent = ({ state, isManual }: { state: string, isManual?: boolean }) => (
  <div className="relative group cursor-pointer">
    <div className={cn(
      "w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all shadow-lg",
      state === 'GREEN' ? "bg-emerald-500/20 border-emerald-500 text-emerald-500 shadow-emerald-500/20" :
      state === 'RED' ? "bg-red-500/20 border-red-500 text-red-500 shadow-red-500/20" :
      "bg-amber-500/20 border-amber-500 text-amber-500 shadow-amber-500/20"
    )}>
      <Signal className="w-4 h-4" />
      {isManual && (
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-slate-900 animate-pulse"></div>
      )}
    </div>
  </div>
);

const createCustomIcon = (content: React.ReactNode) => {
  return L.divIcon({
    html: renderToStaticMarkup(content as any),
    className: 'custom-div-icon',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
  });
};

const createSignalIcon = (content: React.ReactNode) => {
  return L.divIcon({
    html: renderToStaticMarkup(content as any),
    className: 'custom-signal-icon',
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

const MapController = ({ center, viewMode, selectedAmbulance }: { center?: [number, number], viewMode?: string, selectedAmbulance?: string | null }) => {
  const map = useMap();
  
  useEffect(() => {
    map.invalidateSize();
  }, [viewMode, map]);

  useEffect(() => {
    if (center) {
      map.setView(center, map.getZoom());
    }
  }, [center, map]);

  return null;
};

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

import { TrafficAnimation } from './TrafficAnimation';
import { getAmbulanceStrategy, AmbulanceStrategy } from '../services/geminiService';

interface Request {
  id: string;
  ambulanceId: string;
  driverId: string;
  hospitalId: string;
  status: 'PENDING' | 'ACCEPTED' | 'IGNORED' | 'COMPLETED';
  priority: number;
  patientInfo: string;
  createdAt: string;
  acuity?: number;
  eta?: number;
  pickupLocation?: { lat: number, lng: number };
  location?: { lat: number, lng: number };
}

interface TrafficSignal {
  id: string;
  name: string;
  state: 'RED' | 'GREEN' | 'YELLOW' | 'AUTO';
  isManual?: boolean;
  location: { lat: number, lng: number };
}

interface AmbulanceState {
  driverId: string;
  location: { lat: number, lng: number };
  isEmergency?: boolean;
  status: 'available' | 'busy' | 'offline';
  speed?: number;
  heading?: number;
  plateNumber?: string;
  lastUpdate?: string;
}

interface Hospital {
  id: string;
  name: string;
  location: { lat: number, lng: number };
  availableBeds: number;
}

type DashboardTab = 'OVERVIEW' | 'MAP' | 'FLEET' | 'SIGNALS';

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<DashboardTab>('OVERVIEW');
  const [requests, setRequests] = useState<Request[]>([]);
  const [signals, setSignals] = useState<TrafficSignal[]>([]);
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<number>(30);
  const [selectedAmbulance, setSelectedAmbulance] = useState<string | null>(null);
  const [aiStrategy, setAiStrategy] = useState<AmbulanceStrategy | null>(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [ambulances, setAmbulances] = useState<Record<string, AmbulanceState>>({});
  const [viewMode, setViewMode] = useState<'MAP' | 'SIMULATION'>('SIMULATION');
  const [logs, setLogs] = useState<{ id: string, message: string, time: Date, type: 'info' | 'priority' }[]>([]);
  const [stats, setStats] = useState({
    active: 0,
    pending: 0,
    completed: 0
  });
  const [hospitals, setHospitals] = useState<Hospital[]>([]);

  useEffect(() => {
    const unsubscribeHospitals = onSnapshot(collection(db, 'hospitals'), (snapshot) => {
      setHospitals(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Initial fetch of ambulances from Firestore
    const unsubscribeAmbulances = onSnapshot(collection(db, 'ambulances'), (snapshot) => {
      const fleet: Record<string, AmbulanceState> = {};
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        fleet[data.driverId] = {
          driverId: data.driverId,
          location: data.currentLocation || { lat: 12.9716, lng: 77.5946 },
          status: data.status || 'offline',
          plateNumber: data.plateNumber || 'AMB-0000',
          lastUpdate: new Date().toISOString()
        };
      });
      setAmbulances(prev => ({ ...fleet, ...prev }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'ambulances');
    });

    const q = query(collection(db, 'requests'), orderBy('createdAt', 'desc'), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reqs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Request));
      const sortedReqs = [...reqs].sort((a, b) => {
        if (a.status === 'PENDING' && b.status !== 'PENDING') return -1;
        if (a.status !== 'PENDING' && b.status === 'PENDING') return 1;
        return (b.priority || 0) - (a.priority || 0);
      });
      setRequests(sortedReqs);
      setStats({
        active: reqs.filter(r => r.status === 'ACCEPTED').length,
        pending: reqs.filter(r => r.status === 'PENDING').length,
        completed: reqs.filter(r => r.status === 'COMPLETED').length
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'requests');
    });

    const unsubscribeSignals = onSnapshot(collection(db, 'signals'), (snapshot) => {
      setSignals(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TrafficSignal)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'signals');
    });

    socket.on("location_update", (data) => {
      setAmbulances(prev => ({ 
        ...prev, 
        [data.driverId]: {
          ...prev[data.driverId],
          ...data,
          lastUpdate: new Date().toISOString()
        } 
      }));
    });

    socket.on("signal_update", (data) => {
      setSignals(prev => prev.map(s => s.id === data.signalId ? { ...s, state: data.state, isManual: data.isManual } : s));
      
      if (data.reason === "Emergency Priority") {
        const signalName = signals.find(s => s.id === data.signalId)?.name || data.signalId;
        setLogs(prev => [{
          id: Math.random().toString(36).substr(2, 9),
          message: `Priority System: ${signalName} set to GREEN for approaching ambulance`,
          time: new Date(),
          type: 'priority'
        }, ...prev].slice(0, 50));
      }
    });

    return () => {
      unsubscribeHospitals();
      unsubscribeAmbulances();
      unsubscribe();
      unsubscribeSignals();
      socket.off("location_update");
      socket.off("signal_update");
    };
  }, []);

  const handleStatusUpdate = async (id: string, status: Request['status']) => {
    try {
      await updateDoc(doc(db, 'requests', id), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `requests/${id}`);
    }
  };

  const handleSignalOverride = (signalId: string, state: TrafficSignal['state']) => {
    socket.emit("manual_signal_control", {
      signalId,
      state,
      duration: state === 'AUTO' ? null : selectedDuration,
      role: 'admin'
    });
    setSelectedSignal(null);
  };

  const setSelectedAmbulanceWithReset = (id: string | null) => {
    setSelectedAmbulance(id);
    setAiStrategy(null);
  };

  const fetchAIStrategy = async (ambulanceId: string) => {
    const amb = ambulances[ambulanceId];
    if (!amb) return;

    setLoadingAI(true);
    setAiStrategy(null);

    // Find active request for this ambulance
    const activeReq = requests.find(r => r.ambulanceId === ambulanceId && r.status === 'ACCEPTED');
    let destination = undefined;
    
    if (activeReq) {
      if (activeReq.hospitalId) {
        const hospital = hospitals.find(h => h.id === activeReq.hospitalId);
        if (hospital) destination = hospital.location;
      } else if (activeReq.pickupLocation) {
        destination = activeReq.pickupLocation;
      }
    }

    // Get current traffic context (simplified)
    const trafficStatus = "Heavy traffic on MG Road, moderate on Indiranagar 100ft road.";
    const patientCondition = amb.status === 'busy' ? (activeReq?.patientInfo || "Critical Condition") : "Stable - Routine Transfer";

    const strategy = await getAmbulanceStrategy(trafficStatus, patientCondition, amb.location, destination);
    setAiStrategy(strategy);
    setLoadingAI(false);

    if (strategy) {
      setLogs(prev => [{
        id: Math.random().toString(),
        message: `AI Strategy Generated for ${amb.plateNumber}: ${strategy.hospitalSummary}`,
        time: new Date(),
        type: 'info'
      }, ...prev]);
    }
  };

  const fleetList = Object.values(ambulances);

  // Re-fetch AI strategy if ambulance status changes while selected
  useEffect(() => {
    if (selectedAmbulance && ambulances[selectedAmbulance]) {
      const amb = ambulances[selectedAmbulance];
      if (aiStrategy && amb.status === 'busy') {
        fetchAIStrategy(selectedAmbulance);
      }
    }
  }, [selectedAmbulance ? ambulances[selectedAmbulance]?.status : null]);

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden -m-8">
      {/* Sidebar */}
      <div className="w-20 bg-slate-900 border-r border-white/5 flex flex-col items-center py-8 gap-8">
        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-600/20 mb-4">
          <Zap className="w-7 h-7 text-white" />
        </div>
        
        <nav className="flex flex-col gap-4">
          <SidebarItem 
            icon={<Activity className="w-6 h-6" />} 
            label="Overview" 
            active={activeTab === 'OVERVIEW'} 
            onClick={() => setActiveTab('OVERVIEW')} 
          />
          <SidebarItem 
            icon={<MapIcon className="w-6 h-6" />} 
            label="Live Map" 
            active={activeTab === 'MAP'} 
            onClick={() => setActiveTab('MAP')} 
          />
          <SidebarItem 
            icon={<Ambulance className="w-6 h-6" />} 
            label="Fleet" 
            active={activeTab === 'FLEET'} 
            onClick={() => setActiveTab('FLEET')} 
          />
          <SidebarItem 
            icon={<Signal className="w-6 h-6" />} 
            label="Signals" 
            active={activeTab === 'SIGNALS'} 
            onClick={() => setActiveTab('SIGNALS')} 
          />
        </nav>

        <div className="mt-auto">
          <SidebarItem 
            icon={<Settings className="w-6 h-6" />} 
            label="Settings" 
            active={false} 
            onClick={() => {}} 
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
        <AnimatePresence mode="wait">
          {activeTab === 'OVERVIEW' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <StatCard title="Active Incidents" value={stats.active} icon={<Activity className="text-blue-500" />} color="blue" />
                <StatCard title="Pending Requests" value={stats.pending} icon={<AlertTriangle className="text-amber-500" />} color="amber" pulse={stats.pending > 0} />
                <StatCard title="Fleet Online" value={(fleetList as AmbulanceState[]).filter(a => a.status !== 'offline').length} icon={<Ambulance className="text-emerald-500" />} color="emerald" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 bg-slate-900 rounded-3xl border border-white/5 overflow-hidden h-[500px] relative">
                  <div className="absolute top-4 right-4 z-40 flex gap-2">
                    <button 
                      onClick={() => setViewMode('MAP')}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
                        viewMode === 'MAP' ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "bg-slate-900/80 text-slate-400 hover:text-white backdrop-blur-md border border-white/5"
                      )}
                    >
                      <MapIcon className="w-4 h-4" />
                      LIVE MAP
                    </button>
                    <button 
                      onClick={() => setViewMode('SIMULATION')}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
                        viewMode === 'SIMULATION' ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "bg-slate-900/80 text-slate-400 hover:text-white backdrop-blur-md border border-white/5"
                      )}
                    >
                      <Activity className="w-4 h-4" />
                      SIMULATION
                    </button>
                  </div>

                  {viewMode === 'MAP' ? (
                    <MapContainer
                      center={[12.9716, 77.5946]}
                      zoom={13}
                      style={{ width: '100%', height: '100%', background: '#0f172a' }}
                      zoomControl={false}
                    >
                      <TileLayer
                        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                      />
                      <MapController 
                        viewMode={viewMode} 
                        center={selectedAmbulance ? [ambulances[selectedAmbulance].location.lat, ambulances[selectedAmbulance].location.lng] : [12.9716, 77.5946]} 
                      />
                      {/* Map content... */}
                      {renderMapContent()}
                    </MapContainer>
                  ) : (
                    <TrafficAnimation 
                      ambulances={ambulances} 
                      signals={signals} 
                      onSignalClick={setSelectedSignal}
                      onAmbulanceClick={setSelectedAmbulanceWithReset}
                    />
                  )}
                  {renderDetailModals()}
                </div>

                <div className="lg:col-span-4 space-y-6">
                  {renderIncidentQueue()}
                  {renderSystemLogs()}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'MAP' && (
            <motion.div
              key="map-view"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="h-[calc(100vh-4rem)] bg-slate-900 rounded-3xl border border-white/5 overflow-hidden relative"
            >
              <MapContainer
                center={[12.9716, 77.5946]}
                zoom={14}
                style={{ width: '100%', height: '100%', background: '#0f172a' }}
                zoomControl={false}
              >
                <TileLayer
                  url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                />
                <MapController 
                  viewMode="MAP" 
                  center={selectedAmbulance ? [ambulances[selectedAmbulance].location.lat, ambulances[selectedAmbulance].location.lng] : [12.9716, 77.5946]} 
                />
                {renderMapContent()}
              </MapContainer>
              {renderDetailModals()}
              
              {/* Floating Map Menu */}
              <div className="absolute top-6 left-6 z-[1000] flex flex-col gap-2">
                <div className="bg-slate-900/90 backdrop-blur-xl border border-white/10 p-2 rounded-2xl shadow-2xl flex flex-col gap-1">
                  <button className="p-3 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-600/20">
                    <MapIcon className="w-5 h-5" />
                  </button>
                  <button className="p-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all">
                    <Activity className="w-5 h-5" />
                  </button>
                  <div className="h-px bg-white/5 mx-2 my-1" />
                  <button className="p-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all">
                    <Signal className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Map Stats Overlay */}
              <div className="absolute top-6 right-6 z-[1000] flex flex-col gap-4">
                <div className="bg-slate-900/90 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl min-w-[200px]">
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3">Network Status</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400">Active Missions</span>
                      <span className="text-xs font-bold text-blue-500">{stats.active}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400">Response Time</span>
                      <span className="text-xs font-bold text-emerald-500">4.2m</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'FLEET' && (
            <motion.div
              key="fleet"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-black text-white tracking-tight">Fleet Management</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {fleetList.map((amb: any) => (
                  <div key={amb.driverId} className="bg-slate-900 border border-white/5 p-6 rounded-3xl hover:border-blue-500/30 transition-all group">
                    <div className="flex justify-between items-start mb-6">
                      <div className={cn(
                        "w-14 h-14 rounded-2xl flex items-center justify-center",
                        amb.status === 'available' ? "bg-emerald-500/10 text-emerald-500" :
                        amb.status === 'busy' ? "bg-blue-500/10 text-blue-500" : "bg-slate-500/10 text-slate-500"
                      )}>
                        <Ambulance className="w-7 h-7" />
                      </div>
                      <div className="text-right">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                          amb.status === 'available' ? "bg-emerald-500/10 text-emerald-500" :
                          amb.status === 'busy' ? "bg-blue-500/10 text-blue-500" : "bg-slate-500/10 text-slate-500"
                        )}>
                          {amb.status}
                        </span>
                      </div>
                    </div>
                    <h3 className="text-xl font-black text-white mb-1">{amb.plateNumber}</h3>
                    <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mb-6">ID: {amb.driverId.slice(0, 8)}</p>
                    
                    <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/5">
                      <div>
                        <p className="text-[10px] text-slate-600 font-bold uppercase mb-1">Speed</p>
                        <p className="text-lg font-black text-white">{amb.speed || 0} km/h</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-600 font-bold uppercase mb-1">Heading</p>
                        <p className="text-lg font-black text-white">{amb.heading || 0}°</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'SIGNALS' && (
            <motion.div
              key="signals"
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-black text-white tracking-tight">Traffic Control Center</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {signals.map(signal => (
                  <div key={signal.id} className="bg-slate-900 border border-white/5 p-6 rounded-3xl">
                    <div className="flex justify-between items-start mb-6">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center",
                        signal.state === 'GREEN' ? "bg-emerald-500/10 text-emerald-500" :
                        signal.state === 'RED' ? "bg-red-500/10 text-red-500" : "bg-amber-500/10 text-amber-500"
                      )}>
                        <Signal className="w-6 h-6" />
                      </div>
                      {signal.isManual && (
                        <span className="px-2 py-1 bg-blue-500/10 text-blue-500 text-[8px] font-black uppercase rounded border border-blue-500/20">MANUAL</span>
                      )}
                    </div>
                    <h3 className="text-lg font-black text-white mb-4">{signal.name}</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        onClick={() => handleSignalOverride(signal.id, 'GREEN')}
                        className={cn(
                          "py-2 rounded-xl text-[10px] font-black transition-all border",
                          signal.state === 'GREEN' ? "bg-emerald-500 border-emerald-400 text-white" : "bg-slate-800 border-white/5 text-slate-400"
                        )}
                      >
                        GREEN
                      </button>
                      <button 
                        onClick={() => handleSignalOverride(signal.id, 'RED')}
                        className={cn(
                          "py-2 rounded-xl text-[10px] font-black transition-all border",
                          signal.state === 'RED' ? "bg-red-500 border-red-400 text-white" : "bg-slate-800 border-white/5 text-slate-400"
                        )}
                      >
                        RED
                      </button>
                      <button 
                        onClick={() => handleSignalOverride(signal.id, 'AUTO')}
                        className="col-span-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl text-[10px] font-black transition-all border border-white/5"
                      >
                        RESTORE AUTO
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );

  // Helper render functions
  function renderMapContent() {
    return (
      <>
        {/* AI Suggested Route Polyline */}
        {aiStrategy && aiStrategy.routeCoordinates && aiStrategy.routeCoordinates.length > 0 && (
          <Polyline 
            positions={aiStrategy.routeCoordinates}
            pathOptions={{ 
              color: '#3b82f6', 
              weight: 6, 
              opacity: 0.8,
              dashArray: '10, 10',
              lineJoin: 'round'
            }}
          >
            <Popup>
              <div className="bg-slate-900 text-white p-2 rounded-lg border border-blue-500/30">
                <p className="text-[10px] font-black text-blue-500 uppercase mb-1">AI Suggested Route</p>
                <p className="text-xs font-medium">{aiStrategy.route}</p>
              </div>
            </Popup>
          </Polyline>
        )}

        {/* Signal Markers */}
        {signals.map((signal) => (
          <Marker
            key={signal.id}
            position={[signal.location.lat, signal.location.lng]}
            icon={createSignalIcon(<SignalIconComponent state={signal.state} isManual={signal.isManual} />)}
            eventHandlers={{
              click: () => setSelectedSignal(signal.id),
            }}
          />
        ))}

        {/* Ambulance Markers */}
        {(fleetList as AmbulanceState[]).map((amb) => {
          const pendingRequests = requests.filter(r => r.status === 'PENDING');
          let nearestETA = null;
          
          if (pendingRequests.length > 0 && amb.status === 'available') {
            let minDistance = Infinity;
            pendingRequests.forEach(req => {
              const dist = calculateDistance(
                amb.location.lat, amb.location.lng,
                req.pickupLocation?.lat || 12.9716, req.pickupLocation?.lng || 77.5946
              );
              if (dist < minDistance) minDistance = dist;
            });
            
            const minutes = Math.round((minDistance / 20) * 60 * 1.5);
            nearestETA = minutes;
          }

          return (
            <Marker
              key={amb.driverId}
              position={[amb.location.lat, amb.location.lng]}
              icon={createCustomIcon(
                <MapIconComponent 
                  icon={Navigation2} 
                  color={amb.status === 'available' ? 'emerald' : amb.status === 'busy' ? 'blue' : 'slate'}
                  isEmergency={amb.isEmergency}
                />
              )}
              eventHandlers={{
                click: () => setSelectedAmbulanceWithReset(amb.driverId),
              }}
            >
              {nearestETA !== null && (
                <Popup offset={[0, -20]} className="custom-popup">
                  <div className="bg-slate-900 border border-emerald-500/50 px-2 py-1 rounded-lg shadow-xl whitespace-nowrap">
                    <p className="text-[10px] font-black text-emerald-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {nearestETA} MIN TO REQ
                    </p>
                  </div>
                </Popup>
              )}
            </Marker>
          );
        })}
      </>
    );
  }

  function renderDetailModals() {
    return (
      <>
        {/* Ambulance Detail Modal */}
        <AnimatePresence>
          {selectedAmbulance && ambulances[selectedAmbulance] && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-6 left-6 right-6 bg-slate-900/95 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem] shadow-2xl z-[2000]"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-2xl flex items-center justify-center",
                    ambulances[selectedAmbulance].status === 'available' ? "bg-emerald-500/20 text-emerald-500" :
                    ambulances[selectedAmbulance].status === 'busy' ? "bg-blue-500/20 text-blue-500" :
                    "bg-slate-500/20 text-slate-500"
                  )}>
                    <Ambulance className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white">{ambulances[selectedAmbulance].plateNumber}</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Driver: {ambulances[selectedAmbulance].driverId}</p>
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">
                      Status: <span className={cn(
                        "font-bold",
                        ambulances[selectedAmbulance].status === 'available' ? "text-emerald-500" :
                        ambulances[selectedAmbulance].status === 'busy' ? "text-blue-500" : "text-slate-500"
                      )}>{ambulances[selectedAmbulance].status}</span>
                    </p>
                  </div>
                </div>
                <button onClick={() => setSelectedAmbulanceWithReset(null)} className="p-2 bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-colors">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-4 py-4 border-y border-white/5">
                <div className="text-center">
                  <p className="text-[10px] text-slate-600 font-bold uppercase mb-1">Speed</p>
                  <p className="text-lg font-black text-white">{ambulances[selectedAmbulance].speed || 0} <span className="text-[10px] text-slate-500">km/h</span></p>
                </div>
                <div className="text-center border-x border-white/5">
                  <p className="text-[10px] text-slate-600 font-bold uppercase mb-1">Heading</p>
                  <p className="text-lg font-black text-white">{ambulances[selectedAmbulance].heading || 0}°</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-600 font-bold uppercase mb-1">Last Update</p>
                  <p className="text-lg font-black text-white">{ambulances[selectedAmbulance].lastUpdate ? formatDistanceToNow(new Date(ambulances[selectedAmbulance].lastUpdate)) : 'N/A'}</p>
                </div>
              </div>

              <div className="mt-4 flex gap-3">
                <button 
                  onClick={() => fetchAIStrategy(selectedAmbulance)}
                  disabled={loadingAI}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                >
                  {loadingAI ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4" />
                  )}
                  {loadingAI ? 'GENERATING...' : 'AI STRATEGY'}
                </button>
                <button className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl transition-all flex items-center gap-2 font-bold text-xs uppercase">
                  <Phone className="w-4 h-4" />
                  CALL
                </button>
              </div>

              {aiStrategy && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4 text-blue-500" />
                    <h5 className="text-[10px] font-black text-blue-500 uppercase tracking-widest">AI Dispatch Recommendation</h5>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Optimal Route</p>
                      <p className="text-xs text-white leading-relaxed">{aiStrategy.route}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Signals to Preempt</p>
                      <div className="flex gap-2">
                        {aiStrategy.signalsToPreempt.map(s => (
                          <span key={s} className="px-2 py-1 bg-blue-600/20 text-blue-400 rounded-md text-[10px] font-bold border border-blue-500/20 uppercase">
                            {s.replace('_', ' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="pt-2 border-t border-white/5">
                      <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Hospital Brief</p>
                      <p className="text-xs text-slate-300 italic">"{aiStrategy.hospitalSummary}"</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Signal Control Modal */}
        <AnimatePresence>
          {selectedSignal && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-slate-900/95 backdrop-blur-xl border border-white/10 p-6 rounded-3xl shadow-2xl z-[2000] w-64"
            >
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-white">Signal Control</h4>
                <button onClick={() => setSelectedSignal(null)} className="text-slate-500 hover:text-white">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              <p className="text-xs text-slate-400 mb-4 uppercase tracking-widest font-bold">
                {signals.find(s => s.id === selectedSignal)?.name}
              </p>
              
              <div className="mb-4">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-2">Duration (Seconds)</p>
                <div className="grid grid-cols-3 gap-2">
                  {[30, 60, 300].map(d => (
                    <button
                      key={d}
                      onClick={() => setSelectedDuration(d)}
                      className={cn(
                        "py-1.5 rounded-lg text-[10px] font-bold border transition-all",
                        selectedDuration === d 
                          ? "bg-blue-600 border-blue-500 text-white" 
                          : "bg-slate-800 border-white/5 text-slate-400 hover:text-white"
                      )}
                    >
                      {d >= 60 ? `${d/60}M` : `${d}S`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2">
                <button onClick={() => handleSignalOverride(selectedSignal, 'GREEN')} className="py-2 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-500 hover:text-white rounded-xl text-xs font-bold transition-all border border-emerald-500/20">FORCE GREEN</button>
                <button onClick={() => handleSignalOverride(selectedSignal, 'YELLOW')} className="py-2 bg-amber-500/20 hover:bg-amber-500 text-amber-500 hover:text-white rounded-xl text-xs font-bold transition-all border border-amber-500/20">FORCE YELLOW</button>
                <button onClick={() => handleSignalOverride(selectedSignal, 'RED')} className="py-2 bg-red-500/20 hover:bg-red-500 text-red-500 hover:text-white rounded-xl text-xs font-bold transition-all border border-red-500/20">FORCE RED</button>
                <button onClick={() => handleSignalOverride(selectedSignal, 'AUTO')} className="py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-bold transition-all border border-white/5">AUTO / NORMAL</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  function renderIncidentQueue() {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="font-bold text-lg">Incident Queue</h3>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{requests.length} TOTAL</span>
        </div>

        <div className="space-y-3 overflow-y-auto max-h-[350px] pr-2 custom-scrollbar">
          <AnimatePresence mode="popLayout">
            {requests.map((req) => (
              <motion.div
                key={req.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={cn(
                  "p-4 rounded-2xl border transition-all",
                  req.status === 'PENDING' ? "bg-amber-500/5 border-amber-500/20" : "bg-slate-900 border-white/5"
                )}
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center",
                      req.status === 'PENDING' ? "bg-amber-500/20 text-amber-500" : "bg-slate-800 text-slate-400"
                    )}>
                      <Navigation2 className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-bold text-white">REQ-{req.id.slice(0, 5).toUpperCase()}</p>
                        {req.priority >= 4 && <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />}
                      </div>
                      <p className="text-xs text-slate-500">{formatDistanceToNow(new Date(req.createdAt))} ago</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      "px-2 py-1 rounded text-[10px] font-black uppercase tracking-tighter mb-1",
                      req.status === 'PENDING' ? "bg-amber-500 text-black" : 
                      req.status === 'ACCEPTED' ? "bg-blue-500 text-white" : "bg-slate-800 text-slate-400"
                    )}>
                      {req.status}
                    </div>
                    <p className="text-[10px] font-bold text-slate-600 uppercase">Score: {req.priority}/5</p>
                  </div>
                </div>
                <p className="text-sm text-slate-300 mb-4 line-clamp-1 italic">"{req.patientInfo || 'No patient details provided'}"</p>
                <div className="flex gap-2">
                  {req.status === 'PENDING' && (
                    <>
                      <button onClick={() => handleStatusUpdate(req.id, 'ACCEPTED')} className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors">ACCEPT</button>
                      <button onClick={() => handleStatusUpdate(req.id, 'IGNORED')} className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs font-bold rounded-lg transition-colors">IGNORE</button>
                    </>
                  )}
                  {req.status === 'ACCEPTED' && (
                    <button onClick={() => handleStatusUpdate(req.id, 'COMPLETED')} className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition-colors">MARK COMPLETED</button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  function renderSystemLogs() {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="font-bold text-lg">System Logs</h3>
          <Zap className="w-4 h-4 text-blue-500" />
        </div>
        <div className="bg-slate-900 rounded-3xl border border-white/5 overflow-hidden">
          <div className="max-h-[300px] overflow-y-auto custom-scrollbar p-4 space-y-3">
            {logs.length === 0 ? (
              <p className="text-xs text-slate-600 text-center py-8">No active system events</p>
            ) : (
              logs.map(log => (
                <div key={log.id} className={cn(
                  "p-3 rounded-xl border flex gap-3 items-start transition-all",
                  log.type === 'priority' ? "bg-emerald-500/5 border-emerald-500/20" : "bg-slate-950 border-white/5"
                )}>
                  <div className={cn(
                    "w-2 h-2 rounded-full mt-1.5 shrink-0",
                    log.type === 'priority' ? "bg-emerald-500 animate-pulse" : "bg-blue-500"
                  )} />
                  <div>
                    <p className="text-xs text-white font-medium leading-relaxed">{log.message}</p>
                    <p className="text-[10px] text-slate-500 font-bold mt-1">{formatDistanceToNow(log.time)} ago</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }
}

function SidebarItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-12 h-12 rounded-xl flex items-center justify-center transition-all relative group",
        active ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "text-slate-500 hover:text-white hover:bg-slate-800"
      )}
    >
      {icon}
      <div className="absolute left-full ml-4 px-2 py-1 bg-slate-900 text-white text-[10px] font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-[1000] border border-white/5">
        {label}
      </div>
    </button>
  );
}

function StatCard({ title, value, icon, color, pulse }: any) {
  return (
    <div className="bg-slate-900 p-6 rounded-3xl border border-white/5 relative overflow-hidden group">
      <div className={cn("absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 opacity-10 rounded-full blur-2xl", `bg-${color}-500`)}></div>
      <div className="flex items-center justify-between relative z-10">
        <div>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">{title}</p>
          <h4 className="text-3xl font-black text-white">{value}</h4>
        </div>
        <div className={cn("p-3 rounded-2xl bg-slate-800", pulse && "animate-pulse")}>
          {icon}
        </div>
      </div>
    </div>
  );
}
