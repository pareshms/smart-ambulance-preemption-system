import React, { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, addDoc, onSnapshot, query, where, orderBy, limit, updateDoc, doc } from 'firebase/firestore';
import { io } from 'socket.io-client';
import { 
  MapContainer, 
  TileLayer, 
  Marker, 
  useMap
} from 'react-leaflet';
import L from 'leaflet';
import { renderToStaticMarkup } from 'react-dom/server';
import { 
  Ambulance, 
  MapPin, 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  Clock,
  Navigation,
  Hospital as HospitalIcon,
  Search,
  ChevronRight,
  Phone,
  X,
  Map as MapIcon,
  Settings as SettingsIcon,
  User as UserIcon,
  ArrowRight,
  Signal,
  Zap
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const socket = io();

type DriverView = 'HOME' | 'HOSPITAL_SELECT' | 'MAP' | 'SETTINGS' | 'PICKUP_SELECT';

const createCustomIcon = (content: React.ReactNode) => {
  return L.divIcon({
    html: renderToStaticMarkup(content as any),
    className: 'custom-div-icon',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
  });
};

const MapController = ({ center, view }: { center: [number, number], view: string }) => {
  const map = useMap();
  
  useEffect(() => {
    map.invalidateSize();
  }, [view, map]);

  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);

  return null;
};

const PlaceAutocomplete = ({ onPlaceSelect }: { onPlaceSelect: (place: any) => void }) => {
  const [inputValue, setInputValue] = useState('');
  const [predictions, setPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);

    if (value.length < 3) {
      setPredictions([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value)}&countrycodes=in&limit=5`);
      const data = await response.json();
      setPredictions(data);
    } catch (error) {
      console.error("Nominatim error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (place: any) => {
    onPlaceSelect({
      name: place.display_name.split(',')[0],
      geometry: {
        location: {
          lat: () => parseFloat(place.lat),
          lng: () => parseFloat(place.lon)
        }
      },
      formatted_address: place.display_name
    });
    setInputValue(place.display_name.split(',')[0]);
    setPredictions([]);
  };

  return (
    <div className="relative w-full">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
        <input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          placeholder="Enter pickup point or search..."
          className="w-full bg-slate-900/50 border border-white/10 rounded-2xl py-5 pl-14 pr-6 text-sm text-white font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all shadow-xl backdrop-blur-sm"
        />
        {loading && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2">
            <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
      </div>
      
      {predictions.length > 0 && (
        <div className="absolute z-50 w-full mt-2 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
          {predictions.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSelect(p)}
              className="w-full text-left px-4 py-3 hover:bg-slate-800 border-b border-white/5 last:border-0 transition-colors"
            >
              <p className="text-sm text-white font-medium truncate">{p.display_name.split(',')[0]}</p>
              <p className="text-[10px] text-slate-500 truncate">{p.display_name}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export function DriverApp({ user }: { user: any }) {
  const [view, setView] = useState<DriverView>('HOME');
  const [hospitals, setHospitals] = useState<any[]>([]);
  const [selectedHospital, setSelectedHospital] = useState<any>(null);
  const [patientInfo, setPatientInfo] = useState('');
  const [acuity, setAcuity] = useState<number>(3);
  const [activeRequest, setActiveRequest] = useState<any>(null);
  const [pickupLocation, setPickupLocation] = useState<any>(null);
  const [sending, setSending] = useState(false);
  const [currentLocation, setCurrentLocation] = useState({ lat: 12.9716, lng: 77.5946 });

  useEffect(() => {
    const unsubscribeHospitals = onSnapshot(collection(db, 'hospitals'), (snapshot) => {
      setHospitals(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'hospitals');
    });

    const q = query(
      collection(db, 'requests'), 
      where('driverId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(1)
    );
    const unsubscribeRequest = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const reqData = snapshot.docs[0].data();
        const req = { id: snapshot.docs[0].id, ...reqData } as any;
        if (req.status !== 'COMPLETED' && req.status !== 'IGNORED') {
          setActiveRequest(req);
          if (view === 'HOME') setView('MAP');
        } else {
          setActiveRequest(null);
          setView('HOME');
        }
      } else {
        setActiveRequest(null);
        setView('HOME');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'requests');
    });

    const interval = setInterval(() => {
      const heading = Math.floor(Math.random() * 360);
      const speed = activeRequest ? Math.floor(Math.random() * 40) + 40 : 0;
      const newLoc = {
        lat: currentLocation.lat + (Math.random() - 0.5) * 0.001,
        lng: currentLocation.lng + (Math.random() - 0.5) * 0.001
      };
      setCurrentLocation(newLoc);

      if (activeRequest) {
        socket.emit('ambulance_location', {
          requestId: activeRequest.id,
          driverId: user.uid,
          isEmergency: true,
          location: newLoc,
          speed,
          heading,
          status: 'busy'
        });
      } else {
        socket.emit('ambulance_location', {
          driverId: user.uid,
          isEmergency: false,
          location: newLoc,
          speed: 0,
          heading: 0,
          status: 'available'
        });
      }
    }, 3000);

    return () => {
      unsubscribeHospitals();
      unsubscribeRequest();
      clearInterval(interval);
    };
  }, [user.uid, activeRequest, currentLocation]);

  const handleEmergencyStart = () => {
    setView('PICKUP_SELECT');
  };

  const handlePickupSelect = (place: google.maps.places.PlaceResult) => {
    if (place.geometry?.location) {
      const loc = {
        lat: typeof place.geometry.location.lat === 'function' ? place.geometry.location.lat() : (place.geometry.location as any).lat,
        lng: typeof place.geometry.location.lng === 'function' ? place.geometry.location.lng() : (place.geometry.location as any).lng,
        address: place.formatted_address || place.name || 'GPS Coordinates'
      };
      setPickupLocation(loc);
      setView('HOSPITAL_SELECT');
    }
  };

  const handleHospitalSelect = (hospital: any) => {
    setSelectedHospital(hospital);
    confirmRequest(hospital.id);
  };

  const confirmRequest = async (hospitalId: string) => {
    setSending(true);
    try {
      const finalPickup = pickupLocation || { 
        ...currentLocation, 
        address: 'Current GPS Location' 
      };

      await addDoc(collection(db, 'requests'), {
        ambulanceId: `amb_${user.uid}`,
        driverId: user.uid,
        hospitalId: hospitalId,
        status: 'PENDING',
        priority: 5,
        acuity: 5,
        patientInfo: "Emergency Response Initiated",
        createdAt: new Date().toISOString(),
        pickupLocation: finalPickup
      });
      // Update ambulance status
      await updateDoc(doc(db, 'ambulances', `amb_${user.uid}`), {
        status: 'busy'
      });
    } catch (error) {
      console.error("Failed to send request:", error);
    } finally {
      setSending(false);
    }
  };

  const endEmergency = async () => {
    if (activeRequest) {
      await updateDoc(doc(db, 'requests', activeRequest.id), {
        status: 'COMPLETED'
      });
      // Update ambulance status
      await updateDoc(doc(db, 'ambulances', `amb_${user.uid}`), {
        status: 'available'
      });
      setActiveRequest(null);
      setView('HOME');
    }
  };

  return (
    <div className="max-w-md mx-auto h-[800px] bg-slate-950 rounded-[3.5rem] border-[12px] border-slate-900 shadow-2xl overflow-hidden relative flex flex-col font-sans">
      {/* Notch Area */}
      <div className="h-12 w-full flex items-center justify-between px-10 pt-4 z-50">
        <span className="text-sm font-bold text-white/90">9:41</span>
        <div className="w-28 h-7 bg-black rounded-full flex items-center justify-center gap-1.5 border border-white/5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Live GPS</span>
        </div>
        <div className="flex gap-2 items-center">
          <Signal className="w-4 h-4 text-white/70" />
          <Zap className="w-4 h-4 text-white/70" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
        <AnimatePresence mode="wait">
          {view === 'HOME' && (
            <motion.div 
              key="home" 
              initial={{ opacity: 0, scale: 0.9 }} 
              animate={{ opacity: 1, scale: 1 }} 
              exit={{ opacity: 0, scale: 1.1 }} 
              className="h-full flex flex-col items-center justify-center p-8"
            >
              <div className="flex flex-col items-center justify-center relative w-full">
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div 
                    animate={{ 
                      scale: [1, 1.4, 1], 
                      opacity: [0.15, 0.05, 0.15] 
                    }} 
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} 
                    className="w-80 h-80 bg-blue-500 rounded-full blur-[100px]" 
                  />
                </div>
                
                <button 
                  onClick={handleEmergencyStart} 
                  className="relative w-64 h-64 bg-blue-600 rounded-full flex flex-col items-center justify-center shadow-[0_0_100px_rgba(37,99,235,0.4)] hover:scale-105 active:scale-95 transition-all group overflow-hidden"
                >
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border-[1px] border-dashed border-white/20 rounded-full scale-90"
                  />
                  <div className="absolute inset-4 border-2 border-white/10 rounded-full"></div>
                  <AlertCircle className="w-16 h-16 text-white mb-4 group-hover:scale-110 transition-transform" />
                  <span className="text-3xl font-black text-white tracking-tighter">EMERGENCY</span>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                    <span className="text-[10px] font-black text-white/60 uppercase tracking-widest">Ready to Deploy</span>
                  </div>
                </button>
                
                <div className="mt-16 text-center space-y-4">
                  <h2 className="text-xl font-black text-white tracking-tight">System Standby</h2>
                  <p className="text-slate-400 text-sm font-medium leading-relaxed max-w-[260px] mx-auto">
                    Tap the button above to initiate <span className="text-blue-400 font-bold tracking-tight">Green Corridor</span> protocol and alert emergency dispatch.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'PICKUP_SELECT' && (
            <motion.div 
              key="pickup" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }} 
              className="p-8 space-y-8"
            >
              <div className="flex items-center justify-between">
                <button onClick={() => setView('HOME')} className="w-12 h-12 bg-slate-900 rounded-2xl border border-white/5 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                  <X className="w-6 h-6" />
                </button>
                <h2 className="text-2xl font-black text-white tracking-tight">Pickup Point</h2>
                <div className="w-12"></div>
              </div>
              
              <div className="bg-blue-600 border border-blue-400/30 p-6 rounded-[2rem] shadow-xl shadow-blue-900/20 flex gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-[10px] text-white/60 font-black uppercase tracking-widest mb-1">Current Position</p>
                  <p className="text-base text-white font-bold leading-tight">Using real-time GPS coordinates for dispatch...</p>
                </div>
              </div>

              <div className="relative flex items-center gap-4 py-2">
                <div className="h-px flex-1 bg-white/5"></div>
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em]">OR MANUAL SEARCH</span>
                <div className="h-px flex-1 bg-white/5"></div>
              </div>

              <div className="space-y-6">
                <PlaceAutocomplete onPlaceSelect={handlePickupSelect} />

                <button 
                  onClick={() => handlePickupSelect({ geometry: { location: { lat: () => currentLocation.lat, lng: () => currentLocation.lng } } } as any)}
                  className="w-full py-5 bg-slate-900 border border-white/5 rounded-2xl text-white font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-xl"
                >
                  Confirm GPS Location <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {view === 'HOSPITAL_SELECT' && (
            <motion.div 
              key="hospitals" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }} 
              className="p-8 space-y-8"
            >
              <div className="flex items-center justify-between">
                <button onClick={() => setView('HOME')} className="w-12 h-12 bg-slate-900 rounded-2xl border border-white/5 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                  <X className="w-6 h-6" />
                </button>
                <h2 className="text-2xl font-black text-white tracking-tight">Select Facility</h2>
                <div className="w-12"></div>
              </div>

              <div className="relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Search nearest hospitals..." 
                  className="w-full bg-slate-900 border border-white/5 rounded-2xl py-5 pl-14 pr-6 text-sm text-white font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all shadow-xl" 
                />
              </div>

              <div className="space-y-4">
                {hospitals.map(h => (
                  <button 
                    key={h.id} 
                    onClick={() => handleHospitalSelect(h)} 
                    className="w-full text-left p-6 bg-slate-900 border border-white/5 rounded-[2rem] hover:border-blue-500/30 transition-all group relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start mb-5">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors">
                          <HospitalIcon className="w-6 h-6 text-emerald-500" />
                        </div>
                        <div>
                          <h4 className="text-base font-black text-white group-hover:text-blue-400 transition-colors">{h.name}</h4>
                          <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Emergency Center • BLR</p>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-6 pt-5 border-t border-white/5">
                      <div>
                        <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-1.5">Distance</p>
                        <div className="flex items-center gap-2 text-white font-black text-xs">
                          <MapPin className="w-3.5 h-3.5 text-blue-500" /> 1.2 mi
                        </div>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-1.5">Capacity</p>
                        <p className="text-xs text-emerald-500 font-black uppercase tracking-widest">{h.availableBeds} Beds Open</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {view === 'MAP' && (
            <motion.div 
              key="map" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 flex flex-col"
            >
              <div className="absolute inset-0 bg-slate-950">
                <MapContainer
                  center={[currentLocation.lat, currentLocation.lng]}
                  zoom={15}
                  style={{ width: '100%', height: '100%', background: '#0f172a' }}
                  zoomControl={false}
                >
                  <TileLayer
                    url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                  />
                  
                  <MapController center={[currentLocation.lat, currentLocation.lng]} view={view} />
                  
                  <Marker 
                    position={[currentLocation.lat, currentLocation.lng]}
                    icon={createCustomIcon(
                      <div className="relative">
                        <div className="absolute -inset-6 bg-blue-500/20 rounded-full animate-ping"></div>
                        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center border-2 border-white shadow-2xl shadow-blue-600/40">
                          <Navigation className="w-7 h-7 text-white" style={{ transform: `rotate(${currentLocation.heading || 0}deg)` }} />
                        </div>
                      </div>
                    )}
                  />

                  {activeRequest && activeRequest.pickupLocation && (
                    <Marker 
                      position={[activeRequest.pickupLocation.lat, activeRequest.pickupLocation.lng]}
                      icon={createCustomIcon(
                        <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center border-2 border-white shadow-2xl shadow-red-600/40">
                          <MapPin className="w-7 h-7 text-white" />
                        </div>
                      )}
                    />
                  )}

                  {activeRequest && activeRequest.hospitalId && (
                    <Marker 
                      position={[
                        hospitals.find(h => h.id === activeRequest.hospitalId)?.location.lat || 12.9716,
                        hospitals.find(h => h.id === activeRequest.hospitalId)?.location.lng || 77.5946
                      ]}
                      icon={createCustomIcon(
                        <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center border-2 border-white shadow-2xl shadow-emerald-600/40">
                          <HospitalIcon className="w-7 h-7 text-white" />
                        </div>
                      )}
                    />
                  )}
                </MapContainer>
                <div className="absolute inset-0 bg-gradient-to-b from-slate-950/60 via-transparent to-slate-950 pointer-events-none"></div>
              </div>

              {/* Navigation Card */}
              <div className="relative z-10 p-6">
                <motion.div 
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="bg-slate-900/90 backdrop-blur-2xl border border-white/10 p-6 rounded-[2.5rem] flex items-center gap-6 shadow-2xl"
                >
                  <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-600/20">
                    <Navigation className="w-9 h-9 text-white -rotate-45" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1.5">
                      <h3 className="text-3xl font-black text-white tracking-tighter">400<span className="text-sm font-bold ml-1 text-white/60">M</span></h3>
                      <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">Clearing Path</span>
                    </div>
                    <p className="text-sm text-slate-400 font-bold">Turn right onto <span className="text-white">Hosur Road</span></p>
                  </div>
                </motion.div>
              </div>

              <div className="flex-1"></div>

              {/* Mission Details */}
              <div className="relative z-10 p-6 space-y-4">
                <motion.div 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="bg-slate-900/95 backdrop-blur-2xl border border-white/10 p-8 rounded-[3rem] shadow-2xl"
                >
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mb-2">Destination</p>
                      <h3 className="text-2xl font-black text-white tracking-tight leading-tight">
                        {hospitals.find(h => h.id === activeRequest?.hospitalId)?.name || 'Manipal Hospital'}
                      </h3>
                    </div>
                    <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center">
                      <HospitalIcon className="w-6 h-6 text-emerald-500" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6 mb-10">
                    <div className="text-center">
                      <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-2">ETA</p>
                      <p className="text-2xl font-black text-amber-500">14<span className="text-xs ml-0.5">MIN</span></p>
                    </div>
                    <div className="text-center border-x border-white/5">
                      <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-2">Dist</p>
                      <p className="text-2xl font-black text-white">2.4<span className="text-xs ml-0.5">KM</span></p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-2">Status</p>
                      <div className="flex items-center justify-center gap-1.5">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                        <p className="text-xs font-black text-emerald-500 uppercase tracking-widest">Active</p>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={endEmergency} 
                    className="w-full py-6 bg-red-600 hover:bg-red-500 text-white rounded-[1.5rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-red-900/40 transition-all flex items-center justify-center gap-4 group"
                  >
                    <X className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                    END EMERGENCY
                  </button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Navigation Bar */}
      {view !== 'HOME' && (
        <div className="h-24 bg-slate-900/90 backdrop-blur-2xl border-t border-white/5 flex items-center justify-around px-8 absolute bottom-0 left-0 right-0 z-50">
          <button onClick={() => setView('HOME')} className={cn("flex flex-col items-center gap-1.5 transition-all", view === 'HOME' ? "text-blue-500 scale-110" : "text-slate-600 hover:text-slate-400")}>
            <UserIcon className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-widest">Home</span>
          </button>
          <button onClick={() => setView('MAP')} className={cn("flex flex-col items-center gap-1.5 transition-all", view === 'MAP' ? "text-blue-500 scale-110" : "text-slate-600 hover:text-slate-400")}>
            <MapIcon className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-widest">Map</span>
          </button>
          <button onClick={() => setView('HOSPITAL_SELECT')} className={cn("flex flex-col items-center gap-1.5 transition-all", view === 'HOSPITAL_SELECT' ? "text-blue-500 scale-110" : "text-slate-600 hover:text-slate-400")}>
            <HospitalIcon className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-widest">Hospitals</span>
          </button>
          <button className="flex flex-col items-center gap-1.5 text-slate-600 hover:text-slate-400 transition-all">
            <SettingsIcon className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-widest">Setup</span>
          </button>
        </div>
      )}
      
      {/* Home Indicator */}
      <div className="h-1.5 w-36 bg-white/10 rounded-full mx-auto mb-3 absolute bottom-0 left-1/2 -translate-x-1/2 z-[60]"></div>
    </div>
  );
}
