import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Ambulance, Signal, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

interface Junction {
  id: string;
  x: number;
  y: number;
  name: string;
  state: 'RED' | 'GREEN' | 'YELLOW' | 'AUTO';
}

interface TrafficAnimationProps {
  ambulances: any[];
  signals: any[];
  onSignalClick?: (id: string) => void;
  onAmbulanceClick?: (id: string) => void;
}

export const TrafficAnimation = ({ ambulances, signals, onSignalClick, onAmbulanceClick }: TrafficAnimationProps) => {
  // 4 Junctions in a 2x2 grid
  const junctions: Junction[] = [
    { id: 'signal_1', x: 25, y: 25, name: 'North West', state: 'AUTO' },
    { id: 'signal_2', x: 75, y: 25, name: 'North East', state: 'AUTO' },
    { id: 'signal_3', x: 25, y: 75, name: 'South West', state: 'AUTO' },
    { id: 'signal_4', x: 75, y: 75, name: 'South East', state: 'AUTO' },
  ];

  // Map real signal states to our simulation junctions
  const simulatedJunctions = junctions.map(j => {
    const realSignal = signals.find(s => s.id === j.id);
    return {
      ...j,
      state: realSignal?.state || 'AUTO'
    };
  });

  // Show all online ambulances
  const fleetList = Object.values(ambulances).filter(a => a.status !== 'offline');

  return (
    <div className="w-full h-full bg-slate-950 relative overflow-hidden rounded-3xl border border-white/5">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 opacity-10" style={{ 
        backgroundImage: 'radial-gradient(circle, #475569 1px, transparent 1px)', 
        backgroundSize: '40px 40px' 
      }} />

      {/* Connecting Roads */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {/* Horizontal Roads */}
        <line x1="0%" y1="25%" x2="100%" y2="25%" stroke="#1e293b" strokeWidth="40" />
        <line x1="0%" y1="75%" x2="100%" y2="75%" stroke="#1e293b" strokeWidth="40" />
        
        {/* Vertical Roads */}
        <line x1="25%" y1="0%" x2="25%" y2="100%" stroke="#1e293b" strokeWidth="40" />
        <line x1="75%" y1="0%" x2="75%" y2="100%" stroke="#1e293b" strokeWidth="40" />

        {/* Road Markings (Dashed lines) */}
        <line x1="0%" y1="25%" x2="100%" y2="25%" stroke="#334155" strokeWidth="2" strokeDasharray="10,10" />
        <line x1="0%" y1="75%" x2="100%" y2="75%" stroke="#334155" strokeWidth="2" strokeDasharray="10,10" />
        <line x1="25%" y1="0%" x2="25%" y2="100%" stroke="#334155" strokeWidth="2" strokeDasharray="10,10" />
        <line x1="75%" y1="0%" x2="75%" y2="100%" stroke="#334155" strokeWidth="2" strokeDasharray="10,10" />
      </svg>

      {/* Junctions & Signals */}
      {simulatedJunctions.map((j) => (
        <div 
          key={j.id} 
          className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
          style={{ left: `${j.x}%`, top: `${j.y}%` }}
          onClick={() => onSignalClick?.(j.id)}
        >
          {/* Junction Area */}
          <div className="w-20 h-20 bg-slate-800 rounded-lg border border-white/10 flex items-center justify-center relative group-hover:border-blue-500/50 transition-colors">
            {/* Signal Indicator */}
            <div className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500 shadow-lg",
              j.state === 'GREEN' ? "bg-emerald-500/20 text-emerald-500 shadow-emerald-500/20" :
              j.state === 'YELLOW' ? "bg-amber-500/20 text-amber-500 shadow-amber-500/20" :
              j.state === 'RED' ? "bg-red-500/20 text-red-500 shadow-red-500/20" :
              "bg-slate-700 text-slate-400"
            )}>
              <Signal className={cn("w-6 h-6", j.state !== 'AUTO' && "animate-pulse")} />
            </div>

            {/* Label */}
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{j.name}</span>
            </div>

            {/* Priority Active Badge */}
            {j.state === 'GREEN' && (
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -bottom-2 -right-2 bg-blue-500 text-white p-1 rounded-full shadow-lg"
              >
                <Zap className="w-3 h-3 fill-white" />
              </motion.div>
            )}
          </div>
        </div>
      ))}

      {/* Simulated Ambulances */}
      <AnimatePresence>
        {fleetList.map((amb: any, idx) => (
          <motion.div
            key={amb.driverId}
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: 1,
              // Move in different patterns based on status
              left: amb.status === 'busy' 
                ? ["25%", "75%", "75%", "25%", "25%"] 
                : ["10%", "90%", "90%", "10%", "10%"],
              top: amb.status === 'busy'
                ? ["25%", "25%", "75%", "75%", "25%"]
                : ["10%", "10%", "90%", "90%", "10%"],
              rotate: [0, 90, 180, 270, 360]
            }}
            transition={{ 
              duration: amb.status === 'busy' ? 15 : 40, 
              repeat: Infinity, 
              ease: "linear",
              delay: idx * 3
            }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20 cursor-pointer"
            onClick={() => onAmbulanceClick?.(amb.driverId)}
          >
            <div className="relative">
              {/* Siren Effect for busy ambulances */}
              {amb.status === 'busy' && (
                <>
                  <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-20 scale-150" />
                  <div className="absolute inset-0 bg-red-500 rounded-full animate-pulse opacity-20 scale-125" />
                </>
              )}
              
              <div className={cn(
                "w-10 h-10 rounded-xl shadow-2xl flex items-center justify-center border-2 relative z-10 transition-colors",
                amb.status === 'busy' ? "bg-white border-blue-500" : "bg-slate-800 border-emerald-500/50"
              )}>
                <Ambulance className={cn(
                  "w-6 h-6",
                  amb.status === 'busy' ? "text-blue-600" : "text-emerald-500"
                )} />
              </div>

              {/* ID Label */}
              <div className={cn(
                "absolute -top-6 left-1/2 -translate-x-1/2 text-[8px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap shadow-lg",
                amb.status === 'busy' ? "bg-blue-600 text-white" : "bg-slate-800 text-slate-400 border border-white/5"
              )}>
                {amb.status === 'busy' ? 'EMERGENCY' : 'PATROL'}
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Legend */}
      <div className="absolute bottom-6 left-6 flex gap-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-full" />
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Priority Green</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-slate-700 rounded-full" />
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Auto Mode</span>
        </div>
      </div>

      <div className="absolute top-6 right-6 text-right">
        <h3 className="text-sm font-black text-white uppercase tracking-tighter">Live Network Simulation</h3>
        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">4 Node Grid Topology</p>
      </div>
    </div>
  );
};
