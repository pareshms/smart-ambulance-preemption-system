import React from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { LogOut, Bell, Settings, User as UserIcon, Ambulance } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  user: FirebaseUser;
  profile: any;
  onLogout: () => void;
}

export function Layout({ children, user, profile, onLogout }: LayoutProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans">
      {/* Sidebar / Navigation */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-slate-900/50 backdrop-blur-md border-b border-white/5 z-50 px-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Ambulance className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight hidden sm:block">Smart Ambulance</span>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-slate-400 hover:text-white transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-900"></span>
          </button>
          
          <div className="h-8 w-px bg-white/10 mx-2"></div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">{profile?.displayName}</p>
              <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">{profile?.role}</p>
            </div>
            <img 
              src={user.photoURL || `https://ui-avatars.com/api/?name=${profile?.displayName}`} 
              alt="Profile" 
              className="w-10 h-10 rounded-full border border-white/10"
              referrerPolicy="no-referrer"
            />
            <button 
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-red-400 transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-24 pb-12 px-4 max-w-7xl mx-auto">
        {children}
      </main>
    </div>
  );
}
