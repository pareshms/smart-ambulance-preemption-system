import React, { useState, useEffect } from 'react';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, signInAnonymously, User as FirebaseUser } from 'firebase/auth';
import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore';
import { Dashboard } from './components/Dashboard';
import { DriverApp } from './components/DriverApp';
import { Layout } from './components/Layout';
import { Loader2, Ambulance, ShieldAlert, AlertCircle } from 'lucide-react';
import { cn } from './lib/utils';
import { seedData } from './seed';
import { motion, AnimatePresence } from 'framer-motion';

export type UserRole = 'admin' | 'driver' | 'traffic_police';

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  hospitalId?: string;
}

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    console.log("App mounted, starting auth listener");
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Seed data once authenticated
        try {
          await seedData(firebaseUser.uid);
        } catch (e) {
          console.warn("Seeding skipped or failed (likely due to permissions):", e);
        }

        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            setProfile(userDoc.data() as UserProfile);
          } else {
            // Default to driver for demo if not exists
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || 'demo@example.com',
              displayName: firebaseUser.displayName || `Demo User ${firebaseUser.uid.slice(0, 4)}`,
              role: 'driver',
            };
            await setDoc(doc(db, 'users', firebaseUser.uid), newProfile);
            setProfile(newProfile);
          }

          // Ensure ambulance record exists for drivers
          if (userDoc.exists() ? userDoc.data().role === 'driver' : true) {
            const ambId = `amb_${firebaseUser.uid}`;
            const ambDoc = await getDoc(doc(db, 'ambulances', ambId));
            if (!ambDoc.exists()) {
              await setDoc(doc(db, 'ambulances', ambId), {
                id: ambId,
                plateNumber: `KA-01-AM-${firebaseUser.uid.slice(0, 4).toUpperCase()}`,
                driverId: firebaseUser.uid,
                status: 'available',
                currentLocation: { lat: 12.9716, lng: 77.5946 }
              });
            }
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, 'initial_setup');
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleDemoLogin = async () => {
    setAuthError(null);
    try {
      await signInAnonymously(auth);
    } catch (error: any) {
      console.error("Demo login failed:", error);
      if (error.code === 'auth/admin-restricted-operation') {
        setAuthError("Anonymous Auth is disabled. Please enable it in the Firebase Console (Authentication > Sign-in method > Anonymous).");
      } else {
        setAuthError("Demo login failed. Please try again.");
      }
    }
  };

  const handleLogout = () => signOut(auth);

  const updateRole = async (role: UserRole) => {
    if (user && profile) {
      const updatedProfile = { ...profile, role };
      await setDoc(doc(db, 'users', user.uid), updatedProfile);
      setProfile(updatedProfile);
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-950 text-white">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-950 text-white p-4">
        <div className="max-w-md w-full space-y-8 text-center">
          <div className="flex justify-center">
            <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
              <Ambulance className="w-12 h-12 text-emerald-500" />
            </div>
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Smart Ambulance</h1>
          <p className="text-slate-400">Real-time emergency response management system.</p>
          <button
            onClick={handleLogin}
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold transition-all shadow-lg shadow-emerald-900/20"
          >
            Sign in with Google
          </button>
          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-slate-950 px-2 text-slate-500">Or</span></div>
          </div>
          <button
            onClick={handleDemoLogin}
            className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl font-semibold border border-white/5 transition-all"
          >
            Try Demo Mode
          </button>

          {authError && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 text-left"
            >
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold mb-1">Action Required</p>
                  <p className="leading-relaxed">{authError}</p>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  return (
    <Layout user={user} profile={profile} onLogout={handleLogout}>
      <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
        <button 
          onClick={() => updateRole('admin')}
          className={cn("px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap", profile?.role === 'admin' ? "bg-emerald-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700")}
        >
          Control Room
        </button>
        <button 
          onClick={() => updateRole('driver')}
          className={cn("px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap", profile?.role === 'driver' ? "bg-emerald-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700")}
        >
          Driver App
        </button>
      </div>

      {profile?.role === 'admin' && <Dashboard />}
      {profile?.role === 'driver' && (
        <div className="flex justify-center items-center py-4">
          <DriverApp user={user} />
        </div>
      )}
    </Layout>
  );
}
