import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: (process.env as any).GEMINI_API_KEY || '' 
});

export interface AmbulanceStrategy {
  route: string;
  routeCoordinates: [number, number][];
  signalsToPreempt: string[];
  hospitalSummary: string;
}

export async function getAmbulanceStrategy(
  trafficStatus: string, 
  patientCondition: string,
  startLocation: { lat: number, lng: number },
  destinationLocation?: { lat: number, lng: number }
): Promise<AmbulanceStrategy | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-1.5-flash",
      contents: `Act as an Emergency Dispatch AI for Bangalore Traffic.
Current Traffic: ${trafficStatus}
Patient Condition: ${patientCondition}
Start Location: ${startLocation.lat}, ${startLocation.lng}
${destinationLocation ? `Destination: ${destinationLocation.lat}, ${destinationLocation.lng}` : ''}

1. Suggest the optimal route.
2. Provide a list of coordinates (lat, lng) representing the suggested route as a polyline. Include at least 5-8 waypoints to make a smooth path.
3. Identify which 3 traffic signals must be preempted (turned green) immediately (choose from: signal_1, signal_2, signal_3, signal_4).
4. Provide a 1-sentence summary for the hospital staff.

Return the response in a structured format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            route: { type: "string" },
            routeCoordinates: {
              type: "array",
              items: {
                type: "array",
                items: { type: "number" },
                minItems: 2,
                maxItems: 2
              }
            },
            signalsToPreempt: { 
              type: "array", 
              items: { type: "string" } 
            },
            hospitalSummary: { type: "string" }
          },
          required: ["route", "routeCoordinates", "signalsToPreempt", "hospitalSummary"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text.trim());
    }
    return null;
  } catch (error) {
    console.error("Gemini AI Strategy Error:", error);
    return null;
  }
}
